import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { BookOpen, Users, Clock, Briefcase, Heart } from 'lucide-react';

interface CareerMatch {
  id: string;
  title: string;
  match: number;
  description: string;
  salary: string;
  growth: string;
  education: string;
  skills: string[];
}

// Mock data - in a real app, this would come from the backend
const careerMatches: CareerMatch[] = [
  {
    id: 'cm1',
    title: 'Data Scientist',
    match: 92,
    description: 'Data scientists analyze and interpret complex data to help organizations make better decisions.',
    salary: '$100,000 - $150,000',
    growth: '22% (Much faster than average)',
    education: "Bachelor's or Master's degree in Computer Science, Statistics, or related field",
    skills: ['Machine Learning', 'Python', 'SQL', 'Statistics', 'Problem Solving']
  },
  {
    id: 'cm2',
    title: 'UX Designer',
    match: 87,
    description: 'UX Designers create meaningful and relevant experiences for users by researching, prototyping, and designing digital products.',
    salary: '$85,000 - $125,000',
    growth: '13% (Faster than average)',
    education: "Bachelor's degree in Design, HCI, or related field",
    skills: ['User Research', 'Wireframing', 'Prototyping', 'Visual Design', 'Empathy']
  },
  {
    id: 'cm3',
    title: 'Product Manager',
    match: 85,
    description: 'Product Managers identify customer needs and business objectives, then guide product development to meet these goals.',
    salary: '$90,000 - $140,000',
    growth: '10% (Faster than average)',
    education: "Bachelor's degree in Business, Engineering, or related field",
    skills: ['Strategy', 'Communication', 'Roadmapping', 'Analytics', 'Leadership']
  },
  {
    id: 'cm4',
    title: 'Software Engineer',
    match: 80,
    description: 'Software Engineers design and develop computer systems and applications to solve real-world problems.',
    salary: '$90,000 - $135,000',
    growth: '22% (Much faster than average)',
    education: "Bachelor's degree in Computer Science or related field",
    skills: ['JavaScript', 'Python', 'Problem Solving', 'Algorithms', 'System Design']
  },
  {
    id: 'cm5',
    title: 'Marketing Manager',
    match: 75,
    description: 'Marketing Managers develop strategies to promote products and services, identify target audiences, and build brand awareness.',
    salary: '$80,000 - $120,000',
    growth: '10% (Faster than average)',
    education: "Bachelor's degree in Marketing, Business, or related field",
    skills: ['Digital Marketing', 'Analytics', 'Communication', 'Creativity', 'Project Management']
  }
];

const ResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('careers');
  const [selectedCareer, setSelectedCareer] = useState<CareerMatch | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  const handleCareerClick = (career: CareerMatch) => {
    setSelectedCareer(career);
  };

  const handleSaveCareer = (careerId: string) => {
    // This would save the career to the user's profile in a real app
    console.log(`Saved career ${careerId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-xl text-gray-700">Analyzing your results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900">Your Personalized Results</h1>
          <p className="mt-2 text-gray-600 max-w-2xl mx-auto">
            Based on your assessment, we've identified careers that align with your personality traits, skills, and preferences.
          </p>
        </div>

        <div className="flex flex-wrap -mx-4">
          <div className="w-full lg:w-1/3 px-4 mb-8 lg:mb-0">
            <div className="sticky top-24">
              <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
                <div className="p-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Your Personality Profile</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-gray-700">Analytical</span>
                        <span className="text-sm font-medium text-gray-700">85%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-gray-700">Creative</span>
                        <span className="text-sm font-medium text-gray-700">70%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '70%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-gray-700">Leadership</span>
                        <span className="text-sm font-medium text-gray-700">65%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '65%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-gray-700">Social</span>
                        <span className="text-sm font-medium text-gray-700">60%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '60%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-gray-700">Practical</span>
                        <span className="text-sm font-medium text-gray-700">55%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '55%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <Button
                variant="outline"
                onClick={() => navigate('/dashboard')}
                fullWidth
                className="mb-4"
              >
                Save to Dashboard
              </Button>
              
              <Button
                variant="outline"
                onClick={() => navigate('/assessment')}
                fullWidth
              >
                Retake Assessment
              </Button>
            </div>
          </div>
          
          <div className="w-full lg:w-2/3 px-4">
            <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
              <div className="border-b border-gray-200">
                <nav className="flex -mb-px">
                  <button
                    className={`py-4 px-6 font-medium text-sm border-b-2 ${
                      activeTab === 'careers'
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                    onClick={() => setActiveTab('careers')}
                  >
                    Career Matches
                  </button>
                  <button
                    className={`py-4 px-6 font-medium text-sm border-b-2 ${
                      activeTab === 'insights'
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                    onClick={() => setActiveTab('insights')}
                  >
                    Personality Insights
                  </button>
                </nav>
              </div>
              
              <div className="p-6">
                {activeTab === 'careers' ? (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Career Matches</h3>
                    <div className="space-y-4">
                      {careerMatches.map((career) => (
                        <div
                          key={career.id}
                          className={`
                            flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg cursor-pointer transition-all duration-200
                            ${selectedCareer?.id === career.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                            }
                          `}
                          onClick={() => handleCareerClick(career)}
                        >
                          <div className="flex items-center mb-4 sm:mb-0">
                            <div className={`
                              flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center
                              ${career.match > 85 ? 'bg-green-100 text-green-700' : 
                                career.match > 75 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'}
                            `}>
                              <span className="font-bold">{career.match}%</span>
                            </div>
                            <div className="ml-4">
                              <h4 className="text-lg font-semibold text-gray-900">{career.title}</h4>
                              <p className="text-sm text-gray-500 truncate">{career.description.substring(0, 60)}...</p>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="sm:ml-4 flex-shrink-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSaveCareer(career.id);
                            }}
                          >
                            <Heart size={16} className="mr-1" />
                            Save
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Work Style</h3>
                    <p className="mb-6 text-gray-700">
                      Based on your assessment, you thrive in environments that offer both structure and flexibility. You enjoy solving complex problems and have a natural inclination toward analytical thinking.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      <Card className="h-full">
                        <h4 className="text-base font-semibold text-gray-900 mb-2">Strengths</h4>
                        <ul className="space-y-2 text-gray-700">
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-blue-500 mr-2">✓</span>
                            <span>Strong analytical abilities</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-blue-500 mr-2">✓</span>
                            <span>Creative problem-solving</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-blue-500 mr-2">✓</span>
                            <span>Attention to detail</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-blue-500 mr-2">✓</span>
                            <span>Independent thinking</span>
                          </li>
                        </ul>
                      </Card>
                      
                      <Card className="h-full">
                        <h4 className="text-base font-semibold text-gray-900 mb-2">Ideal Environment</h4>
                        <ul className="space-y-2 text-gray-700">
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">✓</span>
                            <span>Collaborative with independent work</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">✓</span>
                            <span>Intellectually stimulating</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">✓</span>
                            <span>Innovative culture</span>
                          </li>
                          <li className="flex items-start">
                            <span className="flex-shrink-0 h-5 w-5 text-green-500 mr-2">✓</span>
                            <span>Recognition for problem-solving</span>
                          </li>
                        </ul>
                      </Card>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Learning Recommendations</h3>
                    <div className="space-y-4">
                      <div className="p-4 border border-gray-200 rounded-lg">
                        <h4 className="text-base font-semibold text-gray-900">Data Science Fundamentals</h4>
                        <p className="text-sm text-gray-600 mb-2">Strengthen your analytical skills with data science courses</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-blue-600 border-blue-500"
                        >
                          Explore Courses
                        </Button>
                      </div>
                      
                      <div className="p-4 border border-gray-200 rounded-lg">
                        <h4 className="text-base font-semibold text-gray-900">Leadership Development</h4>
                        <p className="text-sm text-gray-600 mb-2">Build management skills to advance your career</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-blue-600 border-blue-500"
                        >
                          Explore Courses
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {selectedCareer && activeTab === 'careers' && (
              <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
                <div className="p-6">
                  <div className="flex flex-wrap items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-gray-900">{selectedCareer.title}</h3>
                    <div className="flex items-center">
                      <span className="text-sm font-medium mr-2">Match:</span>
                      <span className={`
                        inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${selectedCareer.match > 85 ? 'bg-green-100 text-green-800' : 
                          selectedCareer.match > 75 ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}
                      `}>
                        {selectedCareer.match}%
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-6">{selectedCareer.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <Briefcase className="h-6 w-6 text-blue-500 mr-3" />
                      <div>
                        <div className="text-sm font-medium text-gray-500">Salary Range</div>
                        <div className="text-base font-semibold text-gray-900">{selectedCareer.salary}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <TrendingUp className="h-6 w-6 text-green-500 mr-3" />
                      <div>
                        <div className="text-sm font-medium text-gray-500">Job Growth</div>
                        <div className="text-base font-semibold text-gray-900">{selectedCareer.growth}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <BookOpen className="h-6 w-6 text-purple-500 mr-3" />
                      <div>
                        <div className="text-sm font-medium text-gray-500">Education</div>
                        <div className="text-base font-semibold text-gray-900">{selectedCareer.education}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                      <Clock className="h-6 w-6 text-orange-500 mr-3" />
                      <div>
                        <div className="text-sm font-medium text-gray-500">Time to Entry</div>
                        <div className="text-base font-semibold text-gray-900">2-4 years</div>
                      </div>
                    </div>
                  </div>
                  
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Key Skills</h4>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {selectedCareer.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                    <Button variant="primary" className="flex-1">
                      <Users className="mr-2 h-5 w-5" />
                      Find Mentors
                    </Button>
                    <Button variant="outline" className="flex-1">
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;