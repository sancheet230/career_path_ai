import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';

interface QuestionOption {
  id: string;
  text: string;
  value: number;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
  category: string;
}

const questions: Question[] = [
  {
    id: 'q1',
    text: 'I enjoy solving complex problems by breaking them down into smaller parts.',
    options: [
      { id: 'q1_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q1_b', text: 'Disagree', value: 2 },
      { id: 'q1_c', text: 'Neutral', value: 3 },
      { id: 'q1_d', text: 'Agree', value: 4 },
      { id: 'q1_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'analytical'
  },
  {
    id: 'q2',
    text: 'I prefer working in teams rather than working alone.',
    options: [
      { id: 'q2_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q2_b', text: 'Disagree', value: 2 },
      { id: 'q2_c', text: 'Neutral', value: 3 },
      { id: 'q2_d', text: 'Agree', value: 4 },
      { id: 'q2_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'social'
  },
  {
    id: 'q3',
    text: 'I enjoy expressing myself creatively.',
    options: [
      { id: 'q3_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q3_b', text: 'Disagree', value: 2 },
      { id: 'q3_c', text: 'Neutral', value: 3 },
      { id: 'q3_d', text: 'Agree', value: 4 },
      { id: 'q3_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'creative'
  },
  {
    id: 'q4',
    text: 'I enjoy taking leadership roles in group settings.',
    options: [
      { id: 'q4_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q4_b', text: 'Disagree', value: 2 },
      { id: 'q4_c', text: 'Neutral', value: 3 },
      { id: 'q4_d', text: 'Agree', value: 4 },
      { id: 'q4_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'leadership'
  },
  {
    id: 'q5',
    text: 'I prefer structured tasks with clear instructions.',
    options: [
      { id: 'q5_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q5_b', text: 'Disagree', value: 2 },
      { id: 'q5_c', text: 'Neutral', value: 3 },
      { id: 'q5_d', text: 'Agree', value: 4 },
      { id: 'q5_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'conventional'
  },
  {
    id: 'q6',
    text: 'I enjoy learning about how things work through hands-on experience.',
    options: [
      { id: 'q6_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q6_b', text: 'Disagree', value: 2 },
      { id: 'q6_c', text: 'Neutral', value: 3 },
      { id: 'q6_d', text: 'Agree', value: 4 },
      { id: 'q6_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'practical'
  },
  {
    id: 'q7',
    text: 'I enjoy helping others learn or develop their skills.',
    options: [
      { id: 'q7_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q7_b', text: 'Disagree', value: 2 },
      { id: 'q7_c', text: 'Neutral', value: 3 },
      { id: 'q7_d', text: 'Agree', value: 4 },
      { id: 'q7_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'helping'
  },
  {
    id: 'q8',
    text: 'I enjoy organizing and planning activities or projects.',
    options: [
      { id: 'q8_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q8_b', text: 'Disagree', value: 2 },
      { id: 'q8_c', text: 'Neutral', value: 3 },
      { id: 'q8_d', text: 'Agree', value: 4 },
      { id: 'q8_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'organizational'
  },
  {
    id: 'q9',
    text: 'I enjoy thinking about abstract concepts and theories.',
    options: [
      { id: 'q9_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q9_b', text: 'Disagree', value: 2 },
      { id: 'q9_c', text: 'Neutral', value: 3 },
      { id: 'q9_d', text: 'Agree', value: 4 },
      { id: 'q9_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'investigative'
  },
  {
    id: 'q10',
    text: 'I enjoy taking calculated risks.',
    options: [
      { id: 'q10_a', text: 'Strongly Disagree', value: 1 },
      { id: 'q10_b', text: 'Disagree', value: 2 },
      { id: 'q10_c', text: 'Neutral', value: 3 },
      { id: 'q10_d', text: 'Agree', value: 4 },
      { id: 'q10_e', text: 'Strongly Agree', value: 5 },
    ],
    category: 'enterprising'
  },
];

const AssessmentPage: React.FC = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isCompleted, setIsCompleted] = useState(false);
  
  const handleOptionSelect = (questionId: string, value: number) => {
    setAnswers({
      ...answers,
      [questionId]: value
    });
  };
  
  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setIsCompleted(true);
    }
  };
  
  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };
  
  const handleSubmit = () => {
    // In a real app, we would submit the answers to the backend for processing
    // For now, we'll simulate the process and navigate to the results page
    navigate('/results');
  };
  
  const currentQuestionData = questions[currentQuestion];
  const hasAnsweredCurrent = answers[currentQuestionData.id] !== undefined;
  
  const progressPercentage = Math.round(
    (Object.keys(answers).length / questions.length) * 100
  );
  
  return (
    <div className="min-h-screen bg-gray-50 pt-20 pb-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {!isCompleted ? (
          <>
            <div className="mb-8 text-center">
              <h1 className="text-3xl font-bold text-gray-900">Personality Assessment</h1>
              <p className="mt-2 text-gray-600">
                Answer honestly to get the most accurate career recommendations.
              </p>
              
              <div className="mt-6">
                <div className="relative pt-1">
                  <div className="flex mb-2 items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                        Progress
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-semibold inline-block text-blue-600">
                        {progressPercentage}%
                      </span>
                    </div>
                  </div>
                  <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                    <div
                      style={{ width: `${progressPercentage}%` }}
                      className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500 transition-all duration-500"
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            
            <Card className="mb-8 transform transition duration-300 hover:scale-[1.01]">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Question {currentQuestion + 1} of {questions.length}
              </h2>
              <p className="text-lg text-gray-700 mb-6">{currentQuestionData.text}</p>
              
              <div className="space-y-3">
                {currentQuestionData.options.map((option) => (
                  <div
                    key={option.id}
                    className={`
                      p-4 rounded-lg cursor-pointer transition-all duration-200
                      ${answers[currentQuestionData.id] === option.value
                        ? 'bg-blue-100 border-2 border-blue-500'
                        : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                      }
                    `}
                    onClick={() => handleOptionSelect(currentQuestionData.id, option.value)}
                  >
                    <span className="text-gray-800">{option.text}</span>
                  </div>
                ))}
              </div>
            </Card>
            
            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
              >
                Previous
              </Button>
              
              <Button
                variant="primary"
                onClick={handleNext}
                disabled={!hasAnsweredCurrent}
              >
                {currentQuestion === questions.length - 1 ? 'Finish' : 'Next'}
              </Button>
            </div>
          </>
        ) : (
          <div className="text-center py-10">
            <div className="bg-white p-8 rounded-xl shadow-md max-w-2xl mx-auto">
              <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-4">
                <svg className="h-10 w-10 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Assessment Complete!</h2>
              <p className="text-gray-600 mb-8">
                Thank you for completing the assessment. We're analyzing your responses to provide personalized career recommendations.
              </p>
              
              <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 justify-center">
                <Button
                  variant="primary"
                  size="lg"
                  onClick={handleSubmit}
                >
                  View My Results
                </Button>
                
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => navigate('/dashboard')}
                >
                  Go to Dashboard
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AssessmentPage;