import React from 'react';
import { ChevronRight, Briefcase, User, TrendingUp, Award } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 py-20 md:py-32 px-4 sm:px-6 lg:px-8">
            <div className="sm:text-center md:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl">
                <span className="block">Discover Your Ideal</span>
                <span className="block text-teal-300">Career Path with AI</span>
              </h1>
              <p className="mt-6 text-base text-blue-100 sm:text-lg md:text-xl max-w-lg md:mx-0 mx-auto">
                Take our AI-powered personality assessment and receive personalized career recommendations aligned with your unique traits and skills.
              </p>
              <div className="mt-10 sm:flex sm:justify-center md:justify-start">
                <div className="rounded-md shadow">
                  <Button 
                    variant="primary" 
                    size="lg"
                    onClick={() => navigate('/assessment')}
                    className="w-full flex items-center justify-center text-white bg-teal-500 hover:bg-teal-600 px-8"
                  >
                    Start Assessment
                    <ChevronRight className="ml-2 h-5 w-5" />
                  </Button>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={() => navigate('/careers')}
                    className="w-full flex items-center justify-center bg-white text-blue-600 hover:bg-blue-50 px-8"
                  >
                    Explore Careers
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-full h-full">
          <svg 
            className="absolute right-0 h-full w-1/2 text-blue-500 transform translate-x-1/2"
            fill="currentColor" 
            viewBox="0 0 100 100" 
            preserveAspectRatio="none"
          >
            <polygon points="0,0 100,0 50,100 0,100" opacity="0.1" />
          </svg>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 sm:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-blue-600 tracking-wide uppercase">Features</h2>
            <p className="mt-1 text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight">
              How it works
            </p>
            <p className="max-w-xl mt-5 mx-auto text-xl text-gray-500">
              Our AI-powered platform helps you discover and pursue your ideal career path through a personalized assessment process.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
              <div className="bg-white pt-6 px-6 pb-8 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="inline-flex items-center justify-center p-2 bg-blue-100 rounded-md">
                  <User className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Personality Assessment</h3>
                <p className="mt-2 text-base text-gray-500">
                  Take our comprehensive quiz to understand your unique traits, strengths, and work preferences.
                </p>
              </div>

              <div className="bg-white pt-6 px-6 pb-8 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="inline-flex items-center justify-center p-2 bg-purple-100 rounded-md">
                  <Briefcase className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Career Recommendations</h3>
                <p className="mt-2 text-base text-gray-500">
                  Receive AI-powered career recommendations that align with your personality and skills.
                </p>
              </div>

              <div className="bg-white pt-6 px-6 pb-8 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="inline-flex items-center justify-center p-2 bg-teal-100 rounded-md">
                  <TrendingUp className="h-6 w-6 text-teal-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Industry Insights</h3>
                <p className="mt-2 text-base text-gray-500">
                  Explore current trends, growth projections, and requirements for your recommended career paths.
                </p>
              </div>

              <div className="bg-white pt-6 px-6 pb-8 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="inline-flex items-center justify-center p-2 bg-orange-100 rounded-md">
                  <Award className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">Mentorship Matching</h3>
                <p className="mt-2 text-base text-gray-500">
                  Connect with industry professionals who can guide you on your chosen career path.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="py-16 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-blue-600 tracking-wide uppercase">Testimonials</h2>
            <p className="mt-1 text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight">
              Success Stories
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-600 italic">
                "The assessment accurately pinpointed my strengths and suggested careers I hadn't considered. I'm now pursuing UX design and couldn't be happier."
              </p>
              <div className="mt-4 flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-teal-500 flex items-center justify-center text-white font-bold">
                    JS
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Jamie Smith</p>
                  <p className="text-sm text-gray-500">UX Designer</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-600 italic">
                "I was stuck in a career that didn't fulfill me. The AI recommendations helped me transition to data science, which better matches my analytical nature."
              </p>
              <div className="mt-4 flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                    MJ
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Michael Johnson</p>
                  <p className="text-sm text-gray-500">Data Scientist</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-600 italic">
                "The mentorship matching feature connected me with an experienced professional in my field who has been instrumental in guiding my career growth."
              </p>
              <div className="mt-4 flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-r from-red-500 to-orange-500 flex items-center justify-center text-white font-bold">
                    AP
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Alicia Patel</p>
                  <p className="text-sm text-gray-500">Marketing Manager</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to discover your ideal career?</span>
            <span className="block text-blue-100">Start your journey today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <Button 
                variant="primary" 
                size="lg"
                onClick={() => navigate('/register')}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                Get Started
              </Button>
            </div>
            <div className="ml-3 inline-flex rounded-md shadow">
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/login')}
                className="text-white border-white hover:bg-blue-700"
              >
                Login
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;